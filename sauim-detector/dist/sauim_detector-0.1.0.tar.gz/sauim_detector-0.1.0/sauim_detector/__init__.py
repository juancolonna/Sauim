from .loader import load_audio
from .classifier import classify_signal